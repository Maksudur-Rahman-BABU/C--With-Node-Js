﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Menu
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private const string V = "Id";

        public MainWindow()
        {
            InitializeComponent();
            List<string> categorys = new List<string>()
            {
                "Fast Food","Set Menu","Fries","Drinks"
            };
            this.cmbCategory.ItemsSource = categorys;
        }

        /*private void Button_Click(object sender, RoutedEventArgs e)
        {

        }*/

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            Food food = new Food();
            food.Id = Convert.ToInt32(txtID.Text);
            food.Category = cmbCategory.SelectedItem.ToString();
            food.FoodName = txtFoodName.Text;
            food.Price = Convert.ToDouble(txtPrice.Text);


            var newFood = "{'Id':'" + food.Id + "','Category' : '" + food.Category + "','FoodName' : '" + food.FoodName + "','Price' : '" + food.Price + "'}";

            var json = File.ReadAllText(@"food.json");
            var jsonObj = JObject.Parse(json);
            var foodArray = jsonObj.GetValue("Food") as JArray;
            var newFoods = JObject.Parse(newFood);
            foodArray.Add(newFoods);

            jsonObj["Food"] = foodArray;
            string newJsonResult = JsonConvert.SerializeObject(jsonObj, Formatting.Indented);
            File.WriteAllText(@"food.json", newJsonResult);

            ShowData();
        }

        private void btnAllFood_Click(object sender, RoutedEventArgs e)
        {
            ShowData();
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            var json = File.ReadAllText(@"food.json");
            var jsonObj = JObject.Parse(json);
            JArray foodUpdateArray = (JArray)jsonObj["Food"];

            var Id = Convert.ToInt32(txtID.Text);
            var Category = cmbCategory.SelectedItem.ToString();
            var FoodName = txtFoodName.Text;
            var Price = txtPrice.Text;

            foreach (var food in foodUpdateArray.Where(obj => obj[V].Value<int>() == Id))
            {
                food["Category"] = !string.IsNullOrEmpty(Category) ? Category : "";
                food["FoodName"] = !string.IsNullOrEmpty(FoodName) ? FoodName : "";
                food["Price"] = !string.IsNullOrEmpty(Price) ? Price : "";
            }
            jsonObj["Food"] = foodUpdateArray;
            string output = JsonConvert.SerializeObject(jsonObj, Formatting.Indented);
            File.WriteAllText(@"food.json", output);
            ShowData();
        }


        private void ShowData()
        {
            var json = File.ReadAllText(@"food.json");
            var jsonObj = JObject.Parse(json);
            if (jsonObj != null)
            {
                JArray menuArray = (JArray)jsonObj["Food"];
                List<Food> food = new List<Food>();
                foreach (var item in menuArray)
                {
                    food.Add(new Food() { Id = Convert.ToInt32(item["Id"]), FoodName = item["FoodName"].ToString(), Price = Convert.ToDouble(item["Price"]) });
                }
                lstFood.ItemsSource = food;
            }
        }

        private void Edit_Click(object sender, RoutedEventArgs e)
        {
            btnUpdate.Visibility = Visibility.Visible;
            Button b = sender as Button;
            Food foBtn = b.CommandParameter as Food;
            int fId = foBtn.Id;

            txtID.Text = foBtn.Id.ToString();
            txtFoodName.Text = foBtn.FoodName.ToString();
            txtPrice.Text = foBtn.Price.ToString();
            txtID.IsEnabled = false;
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            var json = File.ReadAllText(@"food.json");
            var jsonObj = JObject.Parse(json);
            JArray foodDeleteArray = (JArray)jsonObj["Food"];

            Button b = sender as Button;
            Food foBtn = b.CommandParameter as Food;
            int fId = foBtn.Id;

            if (fId > 0)
            {
                var foodToDelete = foodDeleteArray.FirstOrDefault(obj => obj["Id"].Value<int>() == fId);
                foodDeleteArray.Remove(foodToDelete);
                string output = JsonConvert.SerializeObject(jsonObj, Formatting.Indented);
                File.WriteAllText(@"food.json", output);
                MessageBox.Show("Data has been deleted successfully.");
                ShowData();
            }
            else
            {
                MessageBox.Show("Data didn't delete");
            }
        }
    }
}

